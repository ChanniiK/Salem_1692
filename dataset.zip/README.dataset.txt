# Salem 1692 > 2024-04-19 3:03pm
https://universe.roboflow.com/yolov8-ojalh/salem-1692

Provided by a Roboflow user
License: CC BY 4.0

